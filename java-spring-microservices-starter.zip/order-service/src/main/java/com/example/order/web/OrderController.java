package com.example.order.web;

import com.example.order.model.Order;
import com.example.order.repo.OrderRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/orders")
public class OrderController {
    private final OrderRepository repo;
    private final RestClient http;
    private final String usersBaseUrl;

    public OrderController(OrderRepository repo, RestClient http, @Value("${users.baseUrl}") String usersBaseUrl) {
        this.repo = repo;
        this.http = http;
        this.usersBaseUrl = usersBaseUrl;
    }

    record CreateOrderRequest(UUID userId, String productId, Integer quantity) {}

    @PostMapping
    public ResponseEntity<?> create(@RequestBody CreateOrderRequest req) {
        // Service-to-service call: verify user exists
        try {
            http.get().uri(usersBaseUrl + "/users/{id}", req.userId()).retrieve().toBodilessEntity();
        } catch (RestClientResponseException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(
                    "error", "User not found: " + req.userId()
            ));
        }

        Order order = new Order();
        order.setUserId(req.userId());
        order.setProductId(req.productId());
        order.setQuantity(req.quantity() == null ? 1 : req.quantity());
        return ResponseEntity.ok(repo.save(order));
    }

    @GetMapping
    public List<Order> all() { return repo.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Order> one(@PathVariable UUID id) {
        return repo.findById(id).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        if (repo.existsById(id)) { repo.deleteById(id); return ResponseEntity.noContent().build(); }
        return ResponseEntity.notFound().build();
    }
}
