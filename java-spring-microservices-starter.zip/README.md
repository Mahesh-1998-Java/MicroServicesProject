# Java Spring Boot Microservices (User, Product, Order) with Docker

A simple microservices system built with **Java 21**, **Spring Boot 3**, and **Docker**:
- **User Service** (H2 in-memory)
- **Product Service** (MongoDB)
- **Order Service** (PostgreSQL) that calls User Service to verify user on order creation

Includes: REST APIs, Swagger UI, Actuator health checks, and Docker Compose.

## Quick Start

### 0) Prereqs
- Java 21 (Temurin) + Maven 3.9+
- Docker + Docker Compose

### 1) Build all services
```bash
mvn -q -DskipTests package
```

### 2) Run with Docker Compose
```bash
docker compose up --build
```
Services will be available at:
- User: http://localhost:8081
- Product: http://localhost:8082
- Order: http://localhost:8083

### 3) Swagger UIs
- User: http://localhost:8081/swagger-ui/index.html
- Product: http://localhost:8082/swagger-ui/index.html
- Order: http://localhost:8083/swagger-ui/index.html

### 4) Health
- Each service: `/actuator/health` (e.g., http://localhost:8081/actuator/health)

### 5) Sample flow
1. Create a user via `POST /users`
2. Create a product via `POST /products`
3. Create an order via `POST /orders` (Order Service verifies the user exists by calling User Service)

### 6) Run locally (without Docker)
Start backing stores:
- PostgreSQL on `localhost:5432` with `orderdb / postgres / postgres` (docker compose below can help)
- MongoDB on `localhost:27017` with default settings

Then run each service:
```bash
mvn -pl user-service spring-boot:run
mvn -pl product-service spring-boot:run
mvn -pl order-service spring-boot:run
```

## API Hints

### User Service
`POST /users` (create)  
`GET /users` (list)  
`GET /users/{id}` (get)  
`PUT /users/{id}` (update)  
`DELETE /users/{id}` (delete)

### Product Service
`POST /products` (create)  
`GET /products` (list)  
`GET /products/{id}` (get)  
`PUT /products/{id}` (update)  
`DELETE /products/{id}` (delete)

### Order Service
`POST /orders` (create) – verifies user via User Service  
`GET /orders` (list)  
`GET /orders/{id}` (get)  
`DELETE /orders/{id}` (delete)

## GitHub Upload (once downloaded)
```bash
# inside project folder
git init
git add .
git commit -m "Initial commit: microservices starter"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```
> Create the remote repo on GitHub first (empty repo, no README/.gitignore).
